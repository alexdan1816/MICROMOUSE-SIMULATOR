# util

This directory contains miscellaneous scripts used during *mms* development. No
promises that these scripts are useful at all, or that they won't do terrible
things if/when executed.
