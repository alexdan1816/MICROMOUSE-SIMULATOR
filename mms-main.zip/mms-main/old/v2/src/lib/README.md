# lib

Here lies the source for the contributing projects, as detailed by the table in
the [README](https://github.com/mackorone/mms/blob/master/README.md). I've
removed most everything except for what was needed; visit the individual
projects' pages for relevant information which may be missing here.
Additionally, I've made some very small edits to fit our use case. Too see the
edits, simply search this directory for `@mackorone`.
