#include "Driver.h"

int main(int argc, char* argv[]) {
    sim::Driver::drive(argc, argv);
    return 0;
}
