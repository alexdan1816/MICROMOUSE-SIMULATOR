# sim

This directory contains all code that is internal to the simulator. Most users
shouldn't ever have to touch anything in here. But if you're curious, feel free
to have a look around.
