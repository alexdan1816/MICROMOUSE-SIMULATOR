// CPMath stands for Cross Platform Math

#include <cmath>

#undef M_PI
#define M_PI 3.14159265358979323846
#undef M_TWOPI
#define M_TWOPI (2 * M_PI)
