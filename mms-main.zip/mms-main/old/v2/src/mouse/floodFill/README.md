# floodFill

This directory contains the code that was used by the University at Buffalo at
the 2014 IEEE Region 1 Micromouse competition. It started out as an
implementation of the floodfill algorithm (hence the name), but grew/deformed
into an ugly depth-first search based algorithm. Peruse this code cautiously,
as it's definitely more complicated than it needs to be. That being said, it's
a good demonstration of tile text functionality.
