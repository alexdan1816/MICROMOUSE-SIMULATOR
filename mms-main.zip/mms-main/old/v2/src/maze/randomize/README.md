# randomize

This maze-generation algorithm creates a maze by randomly deciding whether or
not each wall should exist. In terms of generating good Micromouse mazes, it's
pretty terrible. But it terms of being a good example of how to write your own
maze-generation algorithm, it's pretty great.
