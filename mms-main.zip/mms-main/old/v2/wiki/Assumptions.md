Here is a list of implicit assumptions that the simulator makes. I thought it'd
be a good idea to keep a list of them, though I don't imagine this to be
terribly useful to anyone.

* We assume that the mouse can rotate freely in a square
* At the beginning of the run, we center the mouse's center of mass on the center of the starting tile
