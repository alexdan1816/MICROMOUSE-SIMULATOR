#pragma once

namespace sim {

void sleep(int millis);

} // namespace sim
