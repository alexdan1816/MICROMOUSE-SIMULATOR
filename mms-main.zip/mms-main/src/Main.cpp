#include "Driver.h"

int main(int argc, char *argv[]) { return mms::Driver::drive(argc, argv); }
