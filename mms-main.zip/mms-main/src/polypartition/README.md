#### polypartition

This is not my code - it was borrowed from another open source project. See
[this page](https://github.com/ivanfratric/polypartition) for more information.
